window.onfocus = moveBack;

function moveBack() {
	self.blur();
}
