window.onload = writeMessage;

function writeMessage() {
	document.getElementById("helloMessage").innerHTML = "Hello, world!";
}
